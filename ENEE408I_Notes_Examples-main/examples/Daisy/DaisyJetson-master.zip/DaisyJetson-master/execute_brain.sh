#!/bin/bash
DISPLAY=:0
./daisy_brain.py --no-video
