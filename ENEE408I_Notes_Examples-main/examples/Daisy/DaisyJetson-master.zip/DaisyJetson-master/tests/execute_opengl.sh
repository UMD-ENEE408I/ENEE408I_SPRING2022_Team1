#!/bin/bash
DISPLAY=:0
python3 pure_face_tracking.py
